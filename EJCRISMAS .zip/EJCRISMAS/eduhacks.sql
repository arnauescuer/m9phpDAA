-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 22-04-2022 a las 13:16:40
-- Versión del servidor: 10.4.21-MariaDB
-- Versión de PHP: 7.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `eduhacks`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ctf`
--

CREATE TABLE `ctf` (
  `idctf` int(11) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `descripcion` varchar(256) NOT NULL,
  `puntuacion` int(11) NOT NULL,
  `fechaPublicacion` date NOT NULL DEFAULT current_timestamp(),
  `iduser` int(11) DEFAULT NULL,
  `archivoPath` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `ctf`
--

INSERT INTO `ctf` (`idctf`, `titulo`, `descripcion`, `puntuacion`, `fechaPublicacion`, `iduser`, `archivoPath`) VALUES
(1, 'Test01', 'Este es el tes01 otra vez', 6, '2022-04-02', 2, '524fe1dec98e67b00d0e5417b0c94307'),
(2, 'test02', 'este es el test02', 14, '2022-04-02', 2, '6c6c3679bd5ed5aabe83928637f0c944'),
(3, 'test03', 'este es el test03', 790, '2022-04-02', 2, '82593a353d92c9ef8d499f081fdf32e6'),
(4, 'test05', 'Hola esto es un test05', 100, '2022-04-20', 8, 'cedce5d650c93bed136185ed8fcd75e3'),
(5, 'Hacking Web', 'hackea tu web para conseguir la flag', 1000, '2022-04-20', 1, '59c4a173def9eabec31a902609df2fda'),
(6, 'dgr', 'sdfg', 12, '2022-04-21', 1, '4e62883a62e5f84d5fc573b2b7fe1f2a'),
(7, 'Brute Force', 'Utiliza el ataque de brute force para conseguir el usuario', 1000, '2022-04-21', 1, '6d521421b9e8ccb66608d6d8e4e5e981'),
(8, 'dhjtg', 'fdghtd', 10, '2022-04-21', 1, 'b6be2f515ae63b3e9409811f45f47814'),
(9, 'dhjtg', 'fdghtd', 10, '2022-04-21', 1, '6e8ca671ff08c016d130e71ffa2eb7a9'),
(10, 'test121', 'Esto es un test', 100, '2022-04-21', 9, '3bf8e80bce2c815e2f8112b27f41d7e2'),
(11, 'test12112', 'Esto es un test12', 100, '2022-04-21', 9, '63cdc599a0374f5db72d2a0c58314aa6'),
(12, 'testhola', 'hola que tal', 100, '2022-04-21', 9, '00f651acdf11f2fdc217fbecec6618c9'),
(13, 'titulo', 'descripcion', 0, '2022-04-21', 3, '0d47eb19027a45fb62af2fbb61245f1a'),
(14, 'titulo', 'descripcion', 0, '2022-04-21', 3, 'e5d4babf022a153e52167fef82cbf84a'),
(15, 'wqfwq', 'wqfqw', 100, '2022-04-21', 8, '331d2c972f59483e0d2402adb18a0f4b'),
(16, 'ultimo', 'test', 100, '2022-04-21', 8, '4ad42c6b2b793b07270a052591e95ca5'),
(17, 'wfwfw', 'wafawfaw', 100, '2022-04-21', 8, '465925ac55428e5b2e98a8e41148a2b6'),
(18, 'holita', 'que tal', 100, '2022-04-21', 8, '44e66d21c5a6538ca749fe5f5268e7f2'),
(19, 'ultimctf', 'aixo es el ultim ctf', 100, '2022-04-21', 8, '631a6522181321349b7dc90dacb2507c'),
(20, 'test0102', 'Hola0102', 100, '2022-04-22', 8, 'f267f49e41c6ab2e39f01b8700e2acba'),
(21, 'vwvw', 'wrw', 100, '2022-04-22', 8, '926f60f2d1e9bdb798975630fe0d4830'),
(22, 'ebe', 'ebe', 100, '2022-04-22', 8, '9790510544f1e22e78082594b457beee'),
(23, 'wfcw', 'cwcw', 50, '2022-04-22', 8, '9e587a7ae221c95e20463160c40f171e'),
(24, 'wfcw', 'cwcw', 50, '2022-04-22', 8, 'e11950a27dde3065b5a360d89256afff'),
(25, 'fwfwvw', 'wvwvw', 95, '2022-04-22', NULL, '63488de89b4e7da576a0256d52334d30'),
(26, 'ultimreptepujat', 'el ultim repte pujat', 97, '2022-04-22', 8, '8dee903d831b8e8c2f9ead0fa3808b4f'),
(27, 'holaa', 'qwf', 98, '2022-04-22', 8, '9472ebdce06a8bff093207d31070fa11'),
(28, 'cwwacc', 'wcwac', 85, '2022-04-22', 8, 'b8fb71510a2f2e5702227c6a2bee9a7d'),
(29, 'cwwacc', 'wcwac', 85, '2022-04-22', 8, 'a3808bd275ea6e106f16d4bf720e1c56'),
(30, 'gege', 'egve', 98, '2022-04-22', 8, '475589fa32dfe9e80e960e69621d65db'),
(31, 'veve', 'wevwe', 92, '2022-04-22', 8, '255907e767396a1d77cfb54da293fcf6'),
(32, 'wafw', 'cwc', 955, '2022-04-22', 8, '4514d3e54ec298b4b6c0259f21cd953a'),
(33, 'ultimct', 'aixo es el ultimctf abans de entregar ', 99, '2022-04-22', 8, 'b2f4df39cde4c589f59c9e772aeecac2'),
(34, 'wcwcw', 'cwq', 98, '2022-04-22', 8, 'ef44bddfec0d010950eb7a169023ce22'),
(35, 'cwcwq', 'qwcqw', 95, '2022-04-22', 8, '29d95690af3db1f6a3f94851b1798cad'),
(36, 'cwqcq', 'qwcqw', 93, '2022-04-22', 8, 'ea05561a474ef56aa3585740f0a0a886'),
(38, 'ultimotest', 'etet', 95, '2022-04-22', 8, '71476278f09209ec6393941384110b5a'),
(39, 'repteultimusuari', 'que tal', 95, '2022-04-22', 10, 'f7e601a3ffcc9dc8320398eef6893c68'),
(40, 'ususario114', 'test', 95, '2022-04-22', 11, 'b0bf5633d321670121b7906b18777e79'),
(41, 'egwg', 'wegwe', 69, '2022-04-22', 3, '5400a50275a6bcb503f6c39397faeddf'),
(42, 'nuevoctf', 'mira como me baila', 10000, '2022-04-22', 12, 'd96f48efef117064a401829fd265f2cb'),
(43, '324', '242', 1213, '2022-04-22', 12, '78bf353925ff66fbee19cf9930d31b15'),
(44, 'wfqw', 'qwfqwc', 90, '2022-04-22', 1, 'b2a952673bd2fce93de863c40866042e');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hashtags`
--

CREATE TABLE `hashtags` (
  `id` int(11) NOT NULL,
  `nom` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `hashtags`
--

INSERT INTO `hashtags` (`id`, `nom`) VALUES
(2, 'Eduhacks'),
(3, 'caca'),
(4, 'catala'),
(5, 'gon'),
(6, 'elaranauesmuyguapo'),
(7, 'eduhacks'),
(8, 'test'),
(9, 'cyberconselll'),
(10, 'sdwd'),
(11, 'wfw'),
(12, 'wfqwf'),
(13, 'wqfqwf'),
(14, 'sdw'),
(15, 'awdwa'),
(16, 'asfwa'),
(17, 'wfwac'),
(18, 'wcwfw'),
(19, NULL),
(20, NULL),
(21, 'adfw'),
(22, 'fwfw'),
(23, 'cwcw'),
(24, 'ege'),
(25, 'eve'),
(26, 'ewvw'),
(27, NULL),
(28, NULL),
(29, NULL),
(30, NULL),
(31, 'afwf'),
(32, 'fwfcwc'),
(33, NULL),
(34, NULL),
(35, NULL),
(36, NULL),
(37, NULL),
(38, NULL),
(39, NULL),
(40, 'asfe'),
(41, 'vev'),
(42, 'cw'),
(43, 'holi'),
(44, 'que'),
(45, 'tal'),
(46, 'estas'),
(47, 'ef'),
(48, 'FD'),
(49, 'w'),
(50, 'ce'),
(51, 'qfq'),
(52, 'ultimotest'),
(53, 'hacks'),
(54, 'quetal'),
(55, 'utlimusuari'),
(56, 'queteal'),
(57, 'fwef'),
(58, 'didactico'),
(59, 'fdhj');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hashtagsctf`
--

CREATE TABLE `hashtagsctf` (
  `idHashtag` int(11) DEFAULT NULL,
  `idctf` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `hashtagsctf`
--

INSERT INTO `hashtagsctf` (`idHashtag`, `idctf`) VALUES
(2, 1),
(2, 2),
(2, 3),
(3, 3),
(4, 3),
(5, 3),
(6, 3),
(7, 4),
(8, 4),
(2, 5),
(2, 6),
(2, 7),
(2, 8),
(2, 9),
(2, 10),
(9, 10),
(2, 11),
(2, 12),
(10, 12),
(11, 12),
(2, 15),
(12, 15),
(13, 15),
(2, 16),
(14, 16),
(15, 16),
(2, 17),
(16, 17),
(17, 17),
(18, 17),
(NULL, 18),
(NULL, 18),
(2, 20),
(21, 20),
(2, 21),
(22, 21),
(23, 21),
(2, 22),
(24, 22),
(25, 22),
(26, 22),
(27, 22),
(28, 22),
(29, 23),
(30, 23),
(2, 24),
(31, 24),
(32, 24),
(33, 25),
(34, 25),
(35, 25),
(36, 26),
(37, 26),
(38, 27),
(39, 27),
(2, 28),
(40, 28),
(2, 29),
(41, 29),
(2, 30),
(24, 30),
(2, 31),
(23, 31),
(42, 31),
(2, 32),
(43, 32),
(44, 32),
(45, 32),
(46, 32),
(2, 33),
(47, 33),
(48, 33),
(49, 33),
(2, 34),
(42, 34),
(50, 34),
(2, 35),
(51, 35),
(2, 36),
(52, 36),
(53, 36),
(54, 36),
(2, 38),
(55, 38),
(2, 39),
(53, 39),
(56, 39),
(2, 40),
(57, 40),
(58, 41),
(59, 42),
(2, 43);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `iduser` int(11) NOT NULL,
  `mail` varchar(40) COLLATE utf8mb4_bin NOT NULL,
  `username` varchar(16) COLLATE utf8mb4_bin NOT NULL,
  `passHash` varchar(60) COLLATE utf8mb4_bin NOT NULL,
  `userFirstName` varchar(60) COLLATE utf8mb4_bin NOT NULL,
  `userLastName` varchar(120) COLLATE utf8mb4_bin NOT NULL,
  `creationDate` datetime NOT NULL,
  `removeDate` datetime NOT NULL,
  `lastSignIn` datetime NOT NULL,
  `active` tinyint(1) NOT NULL,
  `activationDate` datetime DEFAULT NULL,
  `activationCode` char(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `resetPassExpiry` datetime DEFAULT NULL,
  `resetPassCode` char(64) COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`iduser`, `mail`, `username`, `passHash`, `userFirstName`, `userLastName`, `creationDate`, `removeDate`, `lastSignIn`, `active`, `activationDate`, `activationCode`, `resetPassExpiry`, `resetPassCode`) VALUES
(1, 'test@test.com', 'test', '$2y$10$GTZMblTQvd7rotetfHbrJOeai0O95IZBYWr2.MIw33/n0AnaH3S7O', '', '', '2021-12-29 11:05:41', '2021-12-29 11:05:41', '2022-04-22 01:13:23', 1, '0000-00-00 00:00:00', NULL, NULL, NULL),
(2, 'hola@hola.com', 'edu', '$2y$10$GWc26P3Vtle5JPqgZ9hS/eLYJ4to/NTbcDgcg28M9FSPeL8q2GF4y', 'edu', 'martinez', '2022-01-03 06:02:35', '2022-01-03 06:02:35', '2022-04-06 11:40:32', 1, '0000-00-00 00:00:00', NULL, NULL, NULL),
(3, 'didac@didac.com', 'didac', '$2y$10$tZj0.9kvKxe3A.DJVGN.6Oh4YEFFFLWcF7pf8skLglyCP3JxUNi36', 'didac', 'sala', '2022-01-03 06:04:54', '2022-01-03 06:04:54', '2022-04-22 12:07:01', 1, '0000-00-00 00:00:00', NULL, NULL, NULL),
(4, 'toni@toni.com', 'toni', '$2y$10$/adaa8zTs5potTlkCQkSzuzTia8iULCHYkLs7RiTv7xz97qnjeBBa', 'toni', 'toni', '2022-01-03 06:09:49', '2022-01-03 06:09:49', '2022-04-02 03:41:03', 1, '0000-00-00 00:00:00', NULL, NULL, NULL),
(5, 'herreros@herreros.com', 'herreros', '$2y$10$B07oGNzFM6g70ug0nRP1Z.lSvYGSvHvm9S8NzAVwO0eWdM3mWHuha', 'Herreros', 'herreros', '2022-01-12 11:42:37', '2022-01-12 11:42:37', '2022-01-12 11:42:54', 1, '0000-00-00 00:00:00', NULL, NULL, NULL),
(6, 'adria.herrerosl@educem.net', 'bigsabe', '$2y$10$hL/3wHV536dJ1CFm.SSGsuxBRh6.7OwMcm4ibLkdW/untkO0Mhsei', 'big', 'sabe', '2022-03-25 12:36:55', '2022-03-25 12:36:55', '2022-03-25 12:49:06', 1, '2022-03-25 12:37:12', NULL, '2022-03-25 13:18:25', '6d05621ab7cb7b4fb796ca2ffbe1a141e0d4319d3deb6a05322b9de85d69b923'),
(7, 'didac.salae@educem.net', 'holita', '$2y$10$JRbgS5fGoBH9pHCvwx.4iOza5MoPtCP4LmqVwVlsS6uBSnqkBfjYi', 'wafawf', 'awfaw', '2022-02-25 03:24:40', '2022-02-25 03:24:40', '2022-02-25 03:27:46', 1, '2022-02-25 03:25:01', NULL, '2022-02-25 15:55:42', '09eac95eb995b821f45353054da3c7eec5f5171fb061de72f1890679956b12a8'),
(8, 'kiwevey411@aikusy.com', 'hola123', '$2y$10$JYHOiw8MQd6zpN/vP99NNe36JCGaLLkRX07agGwqcPytE1/NIO9ka', 'hola', 'que tal', '2022-04-20 05:09:51', '2022-04-20 05:09:51', '2022-04-22 09:31:32', 1, '2022-04-20 05:10:06', NULL, NULL, NULL),
(9, 'tehafi5106@carsik.com', 'test011', '$2y$10$WbQ9NaJlfLD8/Qp7MppUbuRsFan536LJHZ0exK/qRPhGnSs4qEm3m', 'test', 'hola', '2022-04-21 08:26:01', '2022-04-21 08:26:01', '2022-04-21 08:26:24', 1, '2022-04-21 08:26:12', NULL, NULL, NULL),
(10, 'mapede4778@hhmel.com', 'usernametest', '$2y$10$oiv7U7bkx.ip0y66yk0l0.LaERWRkGcbV/.MAPQgSIWdeYTyYM89m', 'username', 'test', '2022-04-22 09:49:26', '2022-04-22 09:49:26', '2022-04-22 09:53:23', 1, '2022-04-22 09:49:48', NULL, NULL, NULL),
(11, 'kmayertm_i588f@hxsni.com', 'usuario114', '$2y$10$dBQUJaC.6C9lo6No43Dl0.uccEoIkl2bqUmM/83mvXXtBlPAy6aw2', 'usuario', '114', '2022-04-22 09:57:54', '2022-04-22 09:57:54', '2022-04-22 10:00:32', 1, '2022-04-22 09:58:13', NULL, '2022-04-22 10:29:42', '2c7d5490e6050836f8f2f0d496b1c8d6a38d4ffac2b898e6e77751bdcd20ebf5'),
(12, 'arnau.escuera@educem.net', 'pekeejr14', '$2y$10$X1iNFkU33OU92yL1R2RsZ.ykwvcOdtWQUk6/bW8dqWgQk/RrtwHmW', 'arnau', 'escuer', '2022-04-22 12:12:05', '2022-04-22 12:12:05', '2022-04-22 12:13:46', 1, '2022-04-22 12:12:14', NULL, '2022-04-22 12:43:06', 'debc96817a3523d6f3cde58b00abaf6480477744625d0b1f4e406e644ae1763b');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `ctf`
--
ALTER TABLE `ctf`
  ADD PRIMARY KEY (`idctf`),
  ADD KEY `fk_userCtf` (`iduser`);

--
-- Indices de la tabla `hashtags`
--
ALTER TABLE `hashtags`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `hashtagsctf`
--
ALTER TABLE `hashtagsctf`
  ADD KEY `fk_idHashtag` (`idHashtag`),
  ADD KEY `fk_idctf` (`idctf`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`iduser`),
  ADD UNIQUE KEY `mail` (`mail`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `ctf`
--
ALTER TABLE `ctf`
  MODIFY `idctf` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT de la tabla `hashtags`
--
ALTER TABLE `hashtags`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `iduser` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `ctf`
--
ALTER TABLE `ctf`
  ADD CONSTRAINT `fk_userCtf` FOREIGN KEY (`iduser`) REFERENCES `users` (`iduser`);

--
-- Filtros para la tabla `hashtagsctf`
--
ALTER TABLE `hashtagsctf`
  ADD CONSTRAINT `fk_idHashtag` FOREIGN KEY (`idHashtag`) REFERENCES `hashtags` (`id`),
  ADD CONSTRAINT `fk_idctf` FOREIGN KEY (`idctf`) REFERENCES `ctf` (`idctf`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
