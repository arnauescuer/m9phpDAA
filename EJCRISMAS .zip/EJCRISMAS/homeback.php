<?php
session_start();
 $user= $_SESSION['usuari'];
 
if (!isset($_SESSION["usuari"])) {
    header('Location: ../index.php');  
}

    if($_SERVER['REQUEST_METHOD'] == "POST" and isset($_POST['logout']))
    {
        func();
    }
    function func()
    {
        require_once './php/logout.php';       
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>EduHacks</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="">
        <link rel="stylesheet" type="text/css" href="./css/homecss.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<!--Fontawesome CDN-->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    
</head>
    <body>
    <nav class="navbar navbar-dark bg-dark navbar-mod">
          <a class="navbar-brand" href="">
            <img src="https://media3.giphy.com/media/3kK6buLfWXNNSHLObM/giphy.gif?cid=790b7611cfa283cc98cc1e89866581b78a1e11b3cbfd2b4f&rid=giphy.gif&ct=s" width="40" height="40" alt="Eduhacks">
          </a>
        </nav>
            <div class="benvingut">
                <img class="imagenperfil" src="./img/perfil.jpg">Benvingut al Usuari </img>
                <br>
                <?php
                echo "$user" ;
                ?>
                <div>

                </div>
                    <form action="./home.php" method="POST">
                        <button type="submit" class="btn btn-link botologout" name="logout"><i class="fas fa-sign-out-alt"></i></button>
                    </form>
                </div> 
            </div>
            <h1 class="titulo">Eduhacks</h1>
            <div class="texto"> 
                                            <div>
                                                <h1 class="h1tit">SOBRE NOSALTRES</h1>
                                            </div>
                                            <div class="flag">
                                             <h2>¿Qué es Capturar la Bandera?</h2>
                                             <p class="parrafo">Un concurso de capturar la bandera (CTF) es un tipo especial de competencia de seguridad cibernética diseñada para desafiar a sus participantes a resolver problemas de seguridad informática y/o capturar y defender sistemas informáticos. El juego consiste en una serie de desafíos en los que los participantes deben realizar ingeniería inversa, romper, piratear, descifrar o hacer lo que sea necesario para resolver el desafío. Todos los desafíos están configurados con la intención de ser pirateados, por lo que es una excelente forma legal de obtener experiencia práctica.</p>
                                             </div>
                                             <div class=ideaeduhacks>
                                                <h2>Acerca de Eduhacks</h2>
                                                <p></p>
                                             </div>
                                             <div class=ideaeduhacks>
                                                <h2>Quién puede jugar en Eduhacks CTF</h2>
                                                <p> Eduhacks CTFse enfoca principalmente en estudiantes y personas que quieran practicar con seguridad.</p>
                                             </div>
                    </div>
            <div class="loginBox"> <img class="user .col-md-6SS" src="https://media3.giphy.com/media/3kK6buLfWXNNSHLObM/giphy.gif?cid=790b7611cfa283cc98cc1e89866581b78a1e11b3cbfd2b4f&rid=giphy.gif&ct=s" height="250px" width="250px">
            
            <form action="crearCTF.php" method="post" enctype="multipart/form-data">
                <div class="inputBox"> 
                    <input id="title" type="text" name="Title" placeholder="Title"> 
                    <input id="desc" type="text" name="Description" placeholder="Description">
                    <input id="file" type="file" name="File">
                </div> 
                <input type="submit" name="" value="Publicar">
            </form> <a data-toggle="modal" data-target="#exampleModal" id="forgot">Forget Password<br> </a>
            <div class="text-center">
            <a href="./php/register.php">Sign-Up</a> 
            </div>
            
        </div>
    </body>
</html>


  