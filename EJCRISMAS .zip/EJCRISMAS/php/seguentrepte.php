<?php 
if(!empty($_GET['repte'])){
    require('./connecta_db_persistent.php');
    $sqlctfid = 'SELECT * FROM ctf ORDER BY idctf';
    $repte= array();
    $newctfID = $db->prepare($sqlctfid);
    $newctfID->execute();
    foreach($newctfID as $fila){
        $repte[] = $fila;
    }
        do{
        // $newctfID->execute();
        $newID = rand(0, $newctfID->rowCount()-1);
    }while($repte[$newID]['idctf'] == $_GET['repte']);
    header("Location: ../home.php?k=$newID");
    exit;        
}
else{
    header("../home.php");
}
 
?>