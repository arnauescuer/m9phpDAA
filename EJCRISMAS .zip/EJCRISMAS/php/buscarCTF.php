<?php
    function buscaRepte($idRepte)
    {
            require_once('./php/connecta_db_persistent.php');
            $idrepteSQL = 'SELECT * FROM ctf WHERE idctf= :idChallenge';
            $sql = $db->prepare($idrepteSQL);
            $sql->bindParam(':idChallenge', $idRepte);
            $sql->execute();
            if($sql){
                foreach($sql as $fila){
                    if($fila['idctf'] == $idRepte){
                        $repte = $fila;
                    }
                }
            }
            return $repte; 
    }

    function buscarUltimRepte()
    {
        require('./php/connecta_db_persistent.php');
            $idrepteSQL = 'SELECT * FROM ctf ORDER BY idctf DESC LIMIT 1';
            $consql = $db->prepare($idrepteSQL);
            $consql->execute();
            if($consql){
                foreach($consql as $fila){
                    $repte = $fila;
                }
            }
             if(isset($repte)){
                 return $repte;
             }      
    } 

    function cargarHashtag($idctf)
    {
            require('./php/connecta_db_persistent.php');
            $selectHashtag = 'SELECT * FROM `hashtagsctf` WHERE idctf = :idctf';
            $comprobarrepte = $db->prepare($selectHashtag);
            $comprobarrepte->execute(array(':idctf'=>$idctf));
            if($comprobarrepte->rowCount()>0){
                foreach($comprobarrepte as $fila){
                    $hastags[] = $fila['idHashtag'];
                }
                return $hastags;
            }
    }
    


    function BuscaCreador($idusuari)
    {
            $nom="Test";
            require('./php/connecta_db_persistent.php');
            $idusuariSQL = 'SELECT username FROM users WHERE iduser = :idusuari';
            $Idusuari = $db->prepare($idusuariSQL);
            $Idusuari->bindParam(':idusuari',$idusuari);
            $Idusuari->execute();
            if($Idusuari){
                foreach($Idusuari as $fila){
                    $nom = $fila['username'];
                }
            }
            return $nom;
    }
?>