<?php
    function nouCTF($titol,$descripcio,$punts,$idUsuari,$url){
        #echo $url
        $UltimIdusuari=1;
        $arch=move_uploaded_file($_FILES['archivo']['tmp_name'],"./files/".$url);
        if($arch){
            require('./php/connecta_db_persistent.php');
            $sql = "INSERT INTO ctf (titulo,descripcion,puntuacion,archivoPath,iduser)
            VALUES(:titulo,:descripcion,:puntuancion,:urlarchivo,:iduser)";
            $preparada = $db->prepare($sql);
            $preparada->execute(array(":titulo"=>$titol,":descripcion"=>$descripcio,":puntuancion"=>$punts,
                                        ":urlarchivo"=>$url,":iduser"=>$idUsuari));
            $UltimIdusuari = $db->lastInsertId(); 
            return $UltimIdusuari;
        }
        return $UltimIdusuari;
    }

    function crearHashtag($hashtag)
    {
        require('./php/connecta_db_persistent.php');
        $sql = "INSERT INTO hashtags (nom) VALUES(:hashtag)"; 
        $preparada = $db->prepare($sql);
        $preparada->execute(array(":hashtag"=>$hashtag));
        $checkHashtag = $db->lastInsertId();
        agregarHashtag($checkHashtag);
    }

    function agregarHashtag($hashtagID) {
        require('./php/connecta_db_persistent.php');
        $sqlrepteid = 'SELECT * FROM ctf ORDER BY idctf DESC LIMIT 1';
        $repteid = $db->prepare($sqlrepteid);
        $repteid->execute();
        if($repteid){
            foreach($repteid as $valor){
                 $repte = $valor['idctf'];
            }
        }
        $sql = "INSERT INTO hashtagsctf (idHashtag,idctf) 
                VALUES(:hashtagID,:checkChallenge)";
        $preparada = $db->prepare($sql);
        $preparada->execute(array(":hashtagID"=>$hashtagID,":checkChallenge"=> $repte));
    }

    function showHashtags($idctf)
    {
            require('./php/connecta_db_persistent.php');
            $selectHashtag = 'SELECT idHashtag FROM `hashtagsctf` WHERE idctf = :idctf';
            $primerhash = $db->prepare($selectHashtag);
            $primerhash->execute(array(':idctf'=>$idctf));
            $selectHashtag2 = "SELECT nom FROM hashtags WHERE id =':id'";
            $segonhash = $db->prepare($selectHashtag2);
            $segonhash->execute(array(':id'=>$selectHashtag));
            return $segonhash;
            
    }

    function cmphashtag ($hashtags) {
        require('./php/connecta_db_persistent.php');
        $sql = "SELECT * FROM hashtags"; 
        $tag = json_decode($hashtags, true);
        $hashtag = $db->query($sql);
        if($hashtag){
            foreach ($tag as $valor) {
                $flag=0; 
                $hashtag = $db->query($sql);
                foreach($hashtag as $fila){ 

                    if(($valor['value']==$fila['nom']))
                    { 
                        if($flag==0)
                        {
                            agregarHashtag($fila['id']); 
                            $flag=1;
                        } 
                    }
                }

                if ($flag==0)
                { 
                    crearHashtag($valor['value']); 
                }
            }
        }
    }

?>