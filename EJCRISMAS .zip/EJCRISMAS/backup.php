<?php
session_start();
 $user= $_SESSION['usuari'];
 
if (!isset($_SESSION["usuari"])) {
    header('Location: ../index.php');  
}

    if($_SERVER['REQUEST_METHOD'] == "POST" and isset($_POST['logout']))
    {
        func();
    }
    function func()
    {
        require_once './php/logout.php';       
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="./css/homecss.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
         <!--Fontawesome CDN-->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    </head>
    <body>
            <div class="benvingut">
                <img class="imagenperfil" src="./img/perfil.jpg">Benvingut al Usuari
                <br>
                <?php
                echo "$user" ;
                ?>
                <div>
                <form action="./home.php" method="POST">
                    <button type="submit" class="btn btn-link botologout" name="logout"><i class="fas fa-sign-out-alt"></i></button>
                </form>
                </div> 
            </div>
            <div class="texto"> hola</div>
            <div class="loginBox"> <img class="user" src="https://media3.giphy.com/media/3kK6buLfWXNNSHLObM/giphy.gif?cid=790b7611cfa283cc98cc1e89866581b78a1e11b3cbfd2b4f&rid=giphy.gif&ct=s" height="250px" width="250px">
            <form action="index.php" method="post">
                <div class="inputBox"> <input id="uname" type="text" name="Username" placeholder="Username"> <input id="pass" type="password" name="Password" placeholder="Password"> </div> <input type="submit" name="" value="Login">
            </form> <a data-toggle="modal" data-target="#exampleModal" id="forgot">Forget Password<br> </a>
            <div class="text-center">
            <a href="./php/register.php">Sign-Up</a> 
            </div>
        </div>
    </body>
</html>
