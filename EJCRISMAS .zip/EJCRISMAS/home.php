<?php
session_start();
 $usuari= $_SESSION['usuari'];
 $idusuari=$_SESSION['idusuari'];
 require_once("./php/subirCTF.php");
 require_once("./php/buscarCTF.php");
if (!isset($_SESSION["usuari"])) {
    header('Location: ../index.php');  
}
if(isset($_GET['k'])){ 
        $repte = buscaRepte($_GET['k']); 
    }else{ 
         $repte = buscarUltimRepte(); 
    }

    if($_SERVER["REQUEST_METHOD"] == "POST"){
        if(isset($_POST["titulo"]) && isset($_FILES["archivo"])) 
        {        
 
            $titulo=$_POST['titulo'];
            $desc=$_POST['descripcion'];     
            $punt=$_POST['puntuacion'];
            $tags=$_POST['tags']; 
            $link=hash('md4',(time().rand(0,1000). $_FILES['archivo']['name']),false);
           #echo $link;

            //Guardamos los hashtags
            cmphashtag ($tags);
            
            $idRepte = nouCTF($titulo, $desc,$punt,$idusuari,$link);
            header("Location: ./home.php?k=$idRepte");
            exit;
    }
}
    // function func()
    // {
    //     require_once './php/logout.php';       
    // }
     if (isset($repte)) {
         $hashtags = cargarHashtag($repte['idctf']);
     }else{
        $hashtags = cargarHashtag($repte['idctf']);
     }
   

    // //descargar fichero
    // $fileName = basename($repte['archivoPath']);
    // $filePath = 'files/'.$fileName;
    // if(!empty($fileName) && file_exists($filePath)){
    // // Define headers
    // header("Cache-Control: public");
    // header("Content-Description: File Transfer");
    // header("Content-Disposition: attachment; filename=$fileName");
    // header("Content-Type: application/zip");
    // header("Content-Transfer-Encoding: binary");
    
    // // Read the file
    // readfile($filePath);
    // exit;
    // }else{
    // echo 'The file does not exist.';
    // }
    

?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Eduhacks</title>

    <!------------------------------Esto hace que los hashtags molen mas-------------------------------------->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.0/css/bootstrap.min.css" rel="stylesheet"/>
    <link href="https://unpkg.com/@yaireo/tagify/dist/tagify.css" rel="stylesheet" type="text/css" />

    <meta name="description" content="Source code generated using layoutit.com">
    <meta name="author" content="LayoutIt!">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/3f3c03b639.js" crossorigin="anonymous"></script>
    
    <link href="css/boostrap/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </head>
  <body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
            <!-- <div class="benvingut">
                <img class="imagenperfil" src="./img/perfil.jpg">Benvingut Usuari </img>
                <br>
                    <?php
                    echo "$user" ;
                    ?> 
            </div> --> 
            <!-- para la proxima entrega nombre usuario terminar -->
            <!-- <nav class="navbar navbar-dark bg-dark navbar-mod" style="border: solid red 2px;">
                    <a class="navbar-brand" href="">
                        <img src="https://media3.giphy.com/media/3kK6buLfWXNNSHLObM/giphy.gif?cid=790b7611cfa283cc98cc1e89866581b78a1e11b3cbfd2b4f&rid=giphy.gif&ct=s" width="40" height="40" alt="Eduhacks">
                    </a>
             </nav> -->
             <!-- <img src="https://media3.giphy.com/media/3kK6buLfWXNNSHLObM/giphy.gif?cid=790b7611cfa283cc98cc1e89866581b78a1e11b3cbfd2b4f&rid=giphy.gif&ct=s" width="40" height="40" alt="Eduhacks"> -->
             <h3 class="text-center">
                    EDUHACKS
                </h3>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3" >
                <h2>
                    Que es captura la Bandera?
                </h2>
                <p>
                    Un concurso de capturar la bandera (CTF) es un tipo de especial de competencia de seguridad cibernética diseñada para desafiar a sus participantes a resolver problemas de seguridad informática y/o capturar y defender sistemas informáticos.
                </p>
                <div>
                    <br />
                    <div>
                        El juego consiste en una serie de desafíos en los que los participantes deben realizar ingeniera inversa , romper ,piratear, descifrar o hacer lo que sea necesario para resolver el desafío.
                    </div>
                    
                    <div>
                        Todos los desafíos están configurado con la intención de ser pirateados, por lo que es una excelente forma legal de obtener experiencia práctica
                    </div>
                </div>
                
                <p>
                    <a class="btn" href="#">View details »</a>
                </p>
            </div>
            <div class="col-md-3">
                <h2>
                    Quien puede jugar en Eduhacks?
                </h2>
                <p>
                    Eduhacks CTF se enfoca principalmente en estudiantes y personas que quieran participar con seguridad.
                </p>
                <img src="https://media3.giphy.com/media/3kK6buLfWXNNSHLObM/giphy.gif?cid=790b7611cfa283cc98cc1e89866581b78a1e11b3cbfd2b4f&rid=giphy.gif&ct=s" width="90%" height="40%" alt="Eduhacks">
                <p>
                    <a class="btn" href="#">View details »</a>
                </p>
            </div>
            <div class="col-md-3" >
                <h2>
                    Sube tu CTF ahora mismo
                </h2>
                <p>
                    <a class="btn" href="#"></a>
                </p>
                <div class="col-md-11" >
                        <h2>
                            Ultimo CTF
                        </h2>
                        <p>
                                <?php 
                                echo "Titulo:".$repte['titulo'];
                                ?>  
                        </p>

                        <p>
                                <?php 
                                echo "Descripcion:".$repte['descripcion'];
                                ?>  
                        </p>
                        <p>
                                <?php 
                                echo "Puntacion: +".$repte['puntuacion'];
                                ?>  
                        </p>
                        <p>
                                <?php 
                                echo "Fecha Publicacion:".$repte['fechaPublicacion'];
                                ?>  
                        </p>
                        <p>
                                <?php 
                                echo "Dueño:".BuscaCreador($repte['iduser']);

                                ?>  
                        </p>
                        <p>
                                <?php 
                                echo "Archivo:";
                                ?> 
                                <a href="./php/descarga.php?file=<?php echo $repte['archivoPath']?>">Click para Descargar fichero</a> 
                        </p>
                                
                </div>
                <a href="./php/seguentrepte.php?repte=<?php echo $repte['idctf']?>">seguent repte</a>
                <br>
                <!-- campo base de datos para guardar el nombre del archivo  -->
                <!-- Button trigger modal -->
                <!-- <a href="./php/descarga.php?file=<?php echo $repte['archivoPath']?>">Click para Descargar fichero</a> -->
<br>
                <button type="button" class="btn-dark btn" data-toggle="modal" data-target="#exampleModal" style="border-radius:50%; border: solid 2px blueviolet;">
                    <i class="fa-solid fa-plus"></i>
                </button>
                <button type="button" class="btn-dark btn" onclick="window.location.href='./php/logout.php'" style="border-radius:50%; border: solid 2px blueviolet;">
                    <i class="fa-solid fa-right-from-bracket"></i>
                </button>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">CREA TU CTF</h5>
              <img src="https://media3.giphy.com/media/3kK6buLfWXNNSHLObM/giphy.gif?cid=790b7611cfa283cc98cc1e89866581b78a1e11b3cbfd2b4f&rid=giphy.gif&ct=s" width="20%" height="20%" alt="Eduhacks">
            </div>
            <div class="modal-body">
            <form role="form" class="formCTF" method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="exampleInputEmail1">
                            Titulo
                        </label>
                        <input type="text" class="form-control" id="exampleInputEmail1" name="titulo" required/>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">
                            Descripcion
                        </label>
                        <input type="text" class="form-control" id="exampleInputPassword1" name="descripcion" required/>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">
                        Puntuacion
                        </label>
                        <input type="text" class="form-control" id="exampleInputEmail1" name="puntuacion" required/>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">
                        Hastags
                        </label>
                        <input type="text" class="form-control" id="exampleInputEmail1" name="tags" value="Eduhacks" required/>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputFile">
                            Insertar Archivo
                        </label>
                        <input type="file" class="form-control-file" id="exampleInputFile" name="archivo" required/>
                    </div>
                    <button type="submit" class="btn btn-primary" style="border-radius:50%; border: solid 2px blueviolet;float:right;">
                        <i class="fa-solid fa-paper-plane"></i>
                    </button>
        </form>
          </div>
        </div>
    </div>
</div>
<br>
                <label for="exampleInputPassword1">
                    Flag
                </label>
                    <input type="text" class="form-control" id="exampleInputPassword1" name="checkflag" required/>
                <br>
                <button type ="button" class="btnFlag">Check the Flag</button>
                
                </div>
        </div>

    </div>
  </body>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.0/js/bootstrap.min.js"></script>
    <script src="https://unpkg.com/@yaireo/tagify"></script>
    <script src="https://unpkg.com/@yaireo/tagify@3.1.0/dist/tagify.polyfills.min.js"></script>
    <script>
        // The DOM element you wish to replace with Tagify
        var input = document.querySelector('input[name=tags]');

        // initialize Tagify on the above input node reference
        new Tagify(input)
    </script>
</html>